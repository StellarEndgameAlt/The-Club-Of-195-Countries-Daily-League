import { i as extractSheetRef, t as CLUB_ICONS, u as teamFromApi } from "./view-C2z9okGt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chesscom.server-IoIa25kP.js
var UA = "ClubOf195Countries/1.0 (https://www.chess.com/club/the-club-of-195-countries)";
async function chessFetch(url) {
	return fetch(url, { headers: {
		"User-Agent": UA,
		Accept: "application/json"
	} });
}
function minTeamPlayers(settings) {
	if (!settings) return null;
	const raw = settings.min_team_players ?? settings.minTeamPlayers ?? settings.min_required_players ?? null;
	const n = Number(raw);
	return Number.isNaN(n) ? null : n;
}
async function loadMatch(id) {
	const clean = id.replace(/[^\d]/g, "");
	if (!clean) return null;
	try {
		const res = await chessFetch(`https://api.chess.com/pub/match/${clean}`);
		if (!res.ok) return null;
		const json = await res.json();
		const t1 = json.teams?.team1;
		const t2 = json.teams?.team2;
		if (!t1 || !t2) return null;
		return {
			id: clean,
			url: String(json.url ?? `https://www.chess.com/club/matches/${clean}`),
			status: String(json.status ?? "registered"),
			boards: json.boards == null ? null : Number(json.boards),
			timeClass: String(json.settings?.time_class ?? "daily"),
			minTeamPlayers: minTeamPlayers(json.settings),
			teams: [teamFromApi(t1), teamFromApi(t2)]
		};
	} catch {
		return null;
	}
}
async function loadClub(slug) {
	const known = CLUB_ICONS[slug] || "https://www.chess.com/bundles/web/images/user-image.007dad08.svg";
	const fallback = {
		slug,
		name: slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
		icon: known,
		url: `https://www.chess.com/club/${slug}`
	};
	if (!slug) return fallback;
	try {
		const res = await chessFetch(`https://api.chess.com/pub/club/${encodeURIComponent(slug)}`);
		if (!res.ok) return fallback;
		const json = await res.json();
		return {
			slug,
			name: json.name || fallback.name,
			icon: known || json.icon || "https://www.chess.com/bundles/web/images/user-image.007dad08.svg",
			url: json.url || fallback.url,
			members: json.members_count
		};
	} catch {
		return fallback;
	}
}
async function loadSheetText(url) {
	const ref = extractSheetRef(url);
	if (!ref) throw new Error("That does not look like a Google Sheets link. Paste a URL that contains /spreadsheets/d/…");
	const exportUrl = `https://docs.google.com/spreadsheets/d/${ref.id}/export?format=tsv&gid=${ref.gid}`;
	const res = await fetch(exportUrl, {
		headers: {
			"User-Agent": UA,
			Accept: "text/tab-separated-values,text/csv,text/plain,*/*"
		},
		redirect: "follow"
	});
	if (!res.ok) throw new Error("Could not read the sheet. Publish it (File → Share → Anyone with the link) and try again.");
	const text = await res.text();
	if (text.includes("<!DOCTYPE html") || text.includes("accounts.google.com") || text.includes("Sign in")) throw new Error("The sheet is not public. In Google Sheets: Share → Anyone with the link can view, then reload.");
	return text;
}
//#endregion
export { loadClub, loadMatch, loadSheetText };

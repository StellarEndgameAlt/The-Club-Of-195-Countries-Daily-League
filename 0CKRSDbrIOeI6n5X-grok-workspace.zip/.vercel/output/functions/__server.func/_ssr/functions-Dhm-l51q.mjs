import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-Dhm-l51q.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchMatchesFn_createServerFn_handler = createServerRpc({
	id: "701bdbef22013f285ce5e89061b4ee300da8d9dd82827493362a0e12330f1c6e",
	name: "fetchMatchesFn",
	filename: "src/lib/chess/functions.ts"
}, (opts) => fetchMatchesFn.__executeServer(opts));
var fetchMatchesFn = createServerFn({ method: "POST" }).validator(object({ ids: array(string()).max(80) })).handler(fetchMatchesFn_createServerFn_handler, async ({ data }) => {
	const { loadMatch } = await import("./chesscom.server-IoIa25kP.mjs");
	const unique = [...new Set(data.ids.map((id) => id.replace(/[^\d]/g, "")).filter(Boolean))];
	return (await Promise.all(unique.map((id) => loadMatch(id)))).filter((m) => m != null);
});
var fetchClubsFn_createServerFn_handler = createServerRpc({
	id: "15d3243af6ee607ffe7c9b5c5d886e4a43512fcffeaf7731d0dca49deb1b59e8",
	name: "fetchClubsFn",
	filename: "src/lib/chess/functions.ts"
}, (opts) => fetchClubsFn.__executeServer(opts));
var fetchClubsFn = createServerFn({ method: "POST" }).validator(object({ slugs: array(string()).max(40) })).handler(fetchClubsFn_createServerFn_handler, async ({ data }) => {
	const { loadClub } = await import("./chesscom.server-IoIa25kP.mjs");
	const unique = [...new Set(data.slugs.map((s) => s.trim().toLowerCase()).filter(Boolean))];
	return Promise.all(unique.map((slug) => loadClub(slug)));
});
var fetchSheetFn_createServerFn_handler = createServerRpc({
	id: "dfb53e8150fc0cd6dfab24693b8c77df01b8e926c3473f5c73b74e141c42b870",
	name: "fetchSheetFn",
	filename: "src/lib/chess/functions.ts"
}, (opts) => fetchSheetFn.__executeServer(opts));
var fetchSheetFn = createServerFn({ method: "POST" }).validator(object({ url: string().min(8).max(500) })).handler(fetchSheetFn_createServerFn_handler, async ({ data }) => {
	const { loadSheetText } = await import("./chesscom.server-IoIa25kP.mjs");
	return { text: await loadSheetText(data.url) };
});
//#endregion
export { fetchClubsFn_createServerFn_handler, fetchMatchesFn_createServerFn_handler, fetchSheetFn_createServerFn_handler };

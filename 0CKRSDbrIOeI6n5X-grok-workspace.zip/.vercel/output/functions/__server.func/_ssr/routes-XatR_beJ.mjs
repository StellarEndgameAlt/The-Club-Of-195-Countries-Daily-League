import { i as __toESM } from "../_runtime.mjs";
import { a as matchIdFromLink, c as parseTournamentData, l as prettifySlug, n as allClubSlugs, o as matchViewFromPayload, r as allMatchIds, s as parseSample } from "./view-C2z9okGt.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
import { a as ExternalLink, i as Globe, o as ChevronDown, r as LoaderCircle, t as Trophy } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-XatR_beJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-transparent bg-accent text-accent-foreground",
		secondary: "border-transparent bg-secondary text-secondary-foreground",
		outline: "border-border text-muted-foreground",
		win: "border-transparent bg-win/15 text-win",
		loss: "border-transparent bg-loss/15 text-loss",
		draw: "border-transparent bg-draw/15 text-draw"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-secondary", className),
		...props
	});
}
function pointsFromScores(scoreA, scoreB) {
	if (scoreA == null || scoreB == null || Number.isNaN(scoreA) || Number.isNaN(scoreB)) return null;
	if (scoreA > scoreB) return 1;
	if (scoreA < scoreB) return 0;
	return .5;
}
function pointsLabel(p) {
	if (p === 1) return "1";
	if (p === 0) return "0";
	if (p === .5) return "½";
	return "·";
}
function matchKey(a, b) {
	return `${a}|${b}`;
}
function resolveView(views, a, b) {
	const direct = views[matchKey(a, b)];
	if (direct) return {
		view: direct,
		flipped: false
	};
	const flipped = views[matchKey(b, a)];
	if (flipped) return {
		view: flipped,
		flipped: true
	};
	return null;
}
function scoresFor(rec, fallback) {
	if (rec) return rec.flipped ? {
		a: rec.view.scoreB,
		b: rec.view.scoreA,
		forfeited: rec.view.forfeited
	} : {
		a: rec.view.scoreA,
		b: rec.view.scoreB,
		forfeited: rec.view.forfeited
	};
	return {
		a: fallback?.scoreA ?? null,
		b: fallback?.scoreB ?? null,
		forfeited: false
	};
}
function computeStandings(group, views) {
	const table = /* @__PURE__ */ new Map();
	for (const slug of group.clubs) table.set(slug, {
		slug,
		played: 0,
		wins: 0,
		draws: 0,
		losses: 0,
		points: 0,
		boardPoints: 0,
		tiebreak: 0
	});
	const pairwise = /* @__PURE__ */ new Map();
	for (const match of group.matches) {
		const { a, b } = scoresFor(resolveView(views, match.clubA, match.clubB), match);
		const pts = pointsFromScores(a, b);
		if (pts == null || a == null || b == null) continue;
		const home = table.get(match.clubA);
		const away = table.get(match.clubB);
		if (!home || !away) continue;
		home.played += 1;
		away.played += 1;
		home.points += pts;
		away.points += 1 - pts;
		home.boardPoints += a;
		away.boardPoints += b;
		if (pts === 1) {
			home.wins += 1;
			away.losses += 1;
		} else if (pts === 0) {
			away.wins += 1;
			home.losses += 1;
		} else {
			home.draws += 1;
			away.draws += 1;
		}
		pairwise.set(matchKey(match.clubA, match.clubB), pts);
		pairwise.set(matchKey(match.clubB, match.clubA), 1 - pts);
	}
	for (const club of table.values()) {
		let tb = 0;
		for (const other of table.values()) {
			if (other.slug === club.slug) continue;
			const pts = pairwise.get(matchKey(club.slug, other.slug));
			if (pts == null) continue;
			tb += pts * other.points;
		}
		club.tiebreak = tb;
	}
	return [...table.values()].sort((a, b) => {
		if (b.points !== a.points) return b.points - a.points;
		if (b.tiebreak !== a.tiebreak) return b.tiebreak - a.tiebreak;
		if (b.boardPoints !== a.boardPoints) return b.boardPoints - a.boardPoints;
		return a.slug.localeCompare(b.slug);
	});
}
var HOST_CLUB_SLUG = "the-club-of-195-countries";
var HOST_CLUB_NAME = "The Club of 195 Countries";
var HOST_CLUB_URL = "https://www.chess.com/club/the-club-of-195-countries";
function findMatch(group, a, b) {
	return group.matches.find((m) => m.clubA === a && m.clubB === b || m.clubA === b && m.clubB === a);
}
function viewsFromPayloads(group, payloads) {
	const views = {};
	for (const match of group.matches) {
		const id = matchIdFromLink(match.link);
		const payload = id ? payloads[id] : null;
		const view = matchViewFromPayload(payload, match.clubA, match.clubB);
		views[matchKey(match.clubA, match.clubB)] = view;
	}
	return views;
}
function GroupTable({ group, clubs, payloads, loading }) {
	const views = viewsFromPayloads(group, payloads);
	const standings = computeStandings(group, views);
	const order = standings.map((s) => s.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-xl border border-border bg-card shadow-[0_12px_32px_-24px_rgba(18,22,15,0.45)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3 sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold tracking-tight text-foreground",
				children: prettifySlug(group.name)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
				children: [group.clubs.length, " clubs"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "bg-ink text-accent-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "sticky left-0 z-10 bg-ink px-4 py-3 text-left font-display text-xs font-medium tracking-wide",
							children: "Club"
						}),
						order.map((slug) => {
							const club = clubs[slug];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-3 text-center font-medium",
								title: club?.name ?? prettifySlug(slug),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-auto flex size-8 items-center justify-center overflow-hidden rounded-full bg-secondary",
									children: club?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: club.icon,
										alt: "",
										className: "size-8 object-cover",
										referrerPolicy: "no-referrer"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: (club?.name ?? slug).slice(0, 1).toUpperCase()
									})
								})
							}, slug);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-3 text-center font-display text-xs font-medium tracking-wide",
							children: "Pts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-3 text-center font-display text-xs font-medium tracking-wide",
							children: "TB"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: order.map((rowSlug, rank) => {
					const club = clubs[rowSlug];
					const standing = standings[rank];
					const isHost = rowSlug === HOST_CLUB_SLUG;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: cn("border-t border-border", isHost ? "bg-accent/10" : rank % 2 === 1 ? "bg-secondary/40" : "bg-card"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: cn("sticky left-0 z-10 min-w-[196px] px-4 py-2.5 text-left font-medium", isHost ? "bg-card" : rank % 2 === 1 ? "bg-secondary/40" : "bg-card"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 text-right font-sans text-xs tabular-nums text-muted-foreground",
											children: rank + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-8 overflow-hidden rounded-full bg-secondary",
											children: club?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: club.icon,
												alt: "",
												className: "size-8 object-cover",
												referrerPolicy: "no-referrer"
											}) : null
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate font-medium leading-tight",
												children: club?.name ?? prettifySlug(rowSlug)
											}), isHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "default",
												className: "mt-1 text-[10px]",
												children: "Host"
											}) : null]
										})
									]
								})
							}),
							order.map((colSlug) => {
								if (rowSlug === colSlug) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-2 text-center text-muted-foreground",
									children: "—"
								}, colSlug);
								const match = findMatch(group, rowSlug, colSlug);
								if (!match) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-2 text-center text-muted-foreground",
									children: "·"
								}, colSlug);
								const rec = resolveView(views, rowSlug, colSlug);
								const { a, b, forfeited } = scoresFor(rec, rowSlug === match.clubA ? match : {
									scoreA: match.scoreB,
									scoreB: match.scoreA
								});
								const pts = pointsFromScores(a, b);
								const href = match.link || rec?.view.url;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-1.5 py-2 text-center",
									children: loading && pts == null && href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mx-auto h-8 w-12" }) : href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href,
										target: "_blank",
										rel: "noreferrer",
										className: cn("inline-flex min-h-11 min-w-11 flex-col items-center justify-center rounded-md px-2 py-1 text-xs font-semibold tabular-nums transition-colors duration-[var(--motion-quick)] hover:bg-secondary", pts === 1 && "text-win", pts === 0 && "text-loss", pts === .5 && "text-draw", pts == null && "text-muted-foreground"),
										title: "Open Chess.com match",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pts == null ? "Board" : `${a}\u2013${b}${forfeited ? "*" : ""}` }), pts != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-medium uppercase tracking-wide",
											children: pointsLabel(pts)
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "mt-0.5 size-3" })]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "·"
									})
								}, colSlug);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-center font-semibold tabular-nums",
								children: standing?.points ?? 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-center text-muted-foreground tabular-nums",
								children: (standing?.tiebreak ?? 0).toFixed(1)
							})
						]
					}, rowSlug);
				}) })]
			})
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,color,opacity,transform,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-foreground hover:bg-accent/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border",
			outline: "border border-border bg-transparent hover:bg-secondary text-foreground",
			ghost: "hover:bg-secondary text-foreground",
			link: "text-accent underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4 py-2",
			sm: "h-9 rounded-md px-3 text-xs",
			lg: "h-12 rounded-lg px-6",
			icon: "h-11 w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground shadow-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
function SourcePanel({ url, onUrlChange, onLoadUrl, onLoadSample, onLoadText, loading, error, sourceLabel }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [paste, setPaste] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 lg:flex-row lg:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground",
						children: "Google Sheet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: url,
						onChange: (e) => onUrlChange(e.target.value),
						placeholder: "Paste a published Google Sheets URL",
						inputMode: "url",
						autoComplete: "off",
						onKeyDown: (e) => {
							if (e.key === "Enter") onLoadUrl();
						}
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onLoadUrl,
						disabled: loading || !url.trim(),
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, "Load sheet"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onLoadSample,
						disabled: loading,
						children: "Sample tournament"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted-foreground",
				children: [
					"Source: ",
					sourceLabel,
					". Share the sheet with “Anyone with the link”."
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-loss",
				role: "alert",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-3 inline-flex items-center gap-1 text-xs font-medium text-accent",
				onClick: () => setOpen((v) => !v),
				children: ["Sheet format", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-3.5 transition-transform duration-[var(--motion-quick)]", open && "rotate-180") })]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-3 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Crosstable: a ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Round"
						}),
						" row, a",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "group"
						}),
						" row, then one row per club slug with Chess.com match URLs and ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "x"
						}),
						" on the diagonal."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Or a match list with columns",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Home"
						}),
						",",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Away"
						}),
						",",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Match"
						}),
						", optional",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Round"
						}),
						" /",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Group"
						}),
						" /",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "Result"
						}),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: paste,
						onChange: (e) => setPaste(e.target.value),
						rows: 6,
						placeholder: "Or paste TSV / CSV here",
						className: "w-full rounded-md border border-border bg-bg px-3 py-2 font-mono text-xs text-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: !paste.trim(),
						onClick: () => onLoadText(paste),
						children: "Parse pasted table"
					})
				]
			}) : null
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchMatchesFn = createServerFn({ method: "POST" }).validator(object({ ids: array(string()).max(80) })).handler(createSsrRpc("701bdbef22013f285ce5e89061b4ee300da8d9dd82827493362a0e12330f1c6e"));
var fetchClubsFn = createServerFn({ method: "POST" }).validator(object({ slugs: array(string()).max(40) })).handler(createSsrRpc("15d3243af6ee607ffe7c9b5c5d886e4a43512fcffeaf7731d0dca49deb1b59e8"));
var fetchSheetFn = createServerFn({ method: "POST" }).validator(object({ url: string().min(8).max(500) })).handler(createSsrRpc("dfb53e8150fc0cd6dfab24693b8c77df01b8e926c3473f5c73b74e141c42b870"));
var SHEET_KEY = "club195-sheet-url";
function readStoredUrl() {
	if (typeof window === "undefined") return "";
	try {
		return localStorage.getItem(SHEET_KEY) ?? "";
	} catch {
		return "";
	}
}
function Home() {
	const sample = (0, import_react.useMemo)(() => parseSample(), []);
	const [url, setUrl] = (0, import_react.useState)("");
	const [tournament, setTournament] = (0, import_react.useState)(sample);
	const [sourceLabel, setSourceLabel] = (0, import_react.useState)("bundled sample");
	const [roundIndex, setRoundIndex] = (0, import_react.useState)(0);
	const [parseError, setParseError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const stored = readStoredUrl();
		if (stored) setUrl(stored);
	}, []);
	const applyText = (text, label) => {
		const parsed = parseTournamentData(text, tournament.title);
		setTournament(parsed);
		setRoundIndex(0);
		setParseError(null);
		setSourceLabel(label);
	};
	const sheetMut = useMutation({
		mutationFn: (sheetUrl) => fetchSheetFn({ data: { url: sheetUrl } }),
		onSuccess: (res, sheetUrl) => {
			applyText(res.text, "Google Sheet");
			try {
				localStorage.setItem(SHEET_KEY, sheetUrl);
			} catch {}
		},
		onError: (err) => {
			setParseError(err instanceof Error ? err.message : "Could not load sheet.");
		}
	});
	const round = tournament.rounds[roundIndex] ?? tournament.rounds[0];
	const slugs = (0, import_react.useMemo)(() => round ? allClubSlugs({
		title: tournament.title,
		rounds: [round]
	}) : [], [round, tournament.title]);
	const matchIds = (0, import_react.useMemo)(() => round ? allMatchIds({
		title: tournament.title,
		rounds: [round]
	}) : [], [round, tournament.title]);
	const clubsQuery = useQuery({
		queryKey: ["clubs", slugs.join(",")],
		queryFn: () => fetchClubsFn({ data: { slugs } }),
		enabled: slugs.length > 0
	});
	const matchesQuery = useQuery({
		queryKey: ["matches", matchIds.join(",")],
		queryFn: () => fetchMatchesFn({ data: { ids: matchIds } }),
		enabled: matchIds.length > 0
	});
	const clubs = {};
	for (const slug of slugs) clubs[slug] = {
		slug,
		name: slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
		icon: "",
		url: `https://www.chess.com/club/${slug}`
	};
	for (const club of clubsQuery.data ?? []) clubs[club.slug] = club;
	const payloads = {};
	for (const match of matchesQuery.data ?? []) payloads[match.id] = match;
	const host = clubs[HOST_CLUB_SLUG];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "bg-ink text-accent-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6 sm:py-10 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.22em] text-accent-foreground/70",
							children: "Chess.com club"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl",
							children: HOST_CLUB_NAME
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-prose text-sm leading-relaxed text-accent-foreground/75",
							children: "Pairings, points, and board links from the club sheet. Live scores pull from Chess.com when a match URL is present."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-lg border border-accent-foreground/15 bg-accent-foreground/10 px-3 py-2",
						children: [host?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: host.icon,
							alt: "",
							className: "size-10 rounded-full object-cover",
							referrerPolicy: "no-referrer"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 items-center justify-center rounded-full bg-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Host club"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-accent-foreground/70",
							children: host?.members ? `${host.members.toLocaleString()} members` : "Join on Chess.com"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: HOST_CLUB_URL,
							target: "_blank",
							rel: "noreferrer",
							children: "Join the club"
						})
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl space-y-6 px-4 py-8 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcePanel, {
					url,
					onUrlChange: setUrl,
					onLoadUrl: () => {
						if (!url.trim()) return;
						sheetMut.mutate(url.trim());
					},
					onLoadSample: () => {
						setTournament(sample);
						setRoundIndex(0);
						setParseError(null);
						setSourceLabel("bundled sample");
					},
					onLoadText: (text) => {
						try {
							applyText(text, "pasted table");
						} catch (err) {
							setParseError(err instanceof Error ? err.message : "Could not parse table.");
						}
					},
					loading: sheetMut.isPending,
					error: parseError,
					sourceLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-semibold tracking-tight",
						children: tournament.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Win 1 · Draw ½ · Loss 0. Tiebreak is Sonneborn–Berger from match points."
					})] }), tournament.rounds.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: tournament.rounds.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: i === roundIndex ? "default" : "secondary",
							onClick: () => setRoundIndex(i),
							children: r.name
						}, r.name + i))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "inline-flex items-center gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4 text-accent" }), round?.name ?? "Standings"]
					})]
				}),
				!round ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl border border-border bg-card px-4 py-10 text-center text-sm text-muted-foreground",
					children: "No rounds in this sheet yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-6",
					children: round.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupTable, {
						group,
						clubs,
						payloads,
						loading: matchesQuery.isLoading
					}, group.name))
				}),
				clubsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" })]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-border bg-card px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-semibold",
							children: "How points work"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 grid gap-1 text-sm text-muted-foreground sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("font-medium text-win"),
									children: "Win"
								}), " — 1 match point"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-draw",
									children: "Draw"
								}), " — ½ match point"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-loss",
									children: "Loss"
								}), " — 0 match points"] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: "Each score cell is a live Chess.com match. Board points (e.g. 3–1½) come from the match; the Pts column is match points. An asterisk is a forfeit on player count."
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { Home as component };

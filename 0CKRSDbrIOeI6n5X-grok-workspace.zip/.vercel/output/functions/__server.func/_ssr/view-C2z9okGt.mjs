//#region node_modules/.nitro/vite/services/ssr/assets/view-C2z9okGt.js
var SAMPLE_SHEET = `Round 1
group 1
hot-chilli-checkmate	x	https://www.chess.com/club/matches/1983144	https://www.chess.com/club/matches/1983618	https://www.chess.com/club/matches/1983156	https://www.chess.com/club/matches/1983186
the-royal-file	https://www.chess.com/club/matches/1983144	x	https://www.chess.com/club/matches/1983620	https://www.chess.com/club/matches/1983556	https://www.chess.com/club/matches/1983646
hybrid-chess-federation	https://www.chess.com/club/matches/1983618	https://www.chess.com/club/matches/1983620	x	https://www.chess.com/club/matches/1983698	https://www.chess.com/club/matches/1983700
chess-universe	https://www.chess.com/club/matches/1983156	https://www.chess.com/club/matches/1983556	https://www.chess.com/club/matches/1983698	x	https://www.chess.com/club/matches/chess-universe/1983712
the-hindu	https://www.chess.com/club/matches/1983186	https://www.chess.com/club/matches/1983646	https://www.chess.com/club/matches/1983700	https://www.chess.com/club/matches/chess-universe/1983712	x

group 2
the-eternal	x	https://www.chess.com/club/matches/chess-on-earth-2/1983388	https://www.chess.com/club/matches/the-eternal/1983390	https://www.chess.com/club/matches/the-club-of-195-countries/1983394	https://www.chess.com/club/matches/chess-like-a-tiger/1983396
chess-on-earth-2	https://www.chess.com/club/matches/chess-on-earth-2/1983388	x	https://www.chess.com/club/matches/chess-on-earth-2/1983716	https://www.chess.com/club/matches/chess-on-earth-2/1983544	https://www.chess.com/club/matches/chess-on-earth-2/1983688
eminence-in-shadow	https://www.chess.com/club/matches/the-eternal/1983390	https://www.chess.com/club/matches/chess-on-earth-2/1983716	x	https://www.chess.com/club/matches/the-club-of-195-countries/1983634	https://www.chess.com/club/matches/chess-like-a-tiger/1983686
the-club-of-195-countries	https://www.chess.com/club/matches/the-club-of-195-countries/1983394	https://www.chess.com/club/matches/chess-on-earth-2/1983544	https://www.chess.com/club/matches/the-club-of-195-countries/1983634	x	https://www.chess.com/club/matches/chess-like-a-tiger/1983526
chess-like-a-tiger	https://www.chess.com/club/matches/chess-like-a-tiger/1983396	https://www.chess.com/club/matches/chess-on-earth-2/1983688	https://www.chess.com/club/matches/chess-like-a-tiger/1983686	https://www.chess.com/club/matches/chess-like-a-tiger/1983526	x
`;
var SAMPLE_TITLE = "Daily Club Tournament";
var CLUB_ICONS = {
	"hot-chilli-checkmate": "https://images.chesscomfiles.com/uploads/v1/group/856887.ca0c5404.160x160o.1b7d241b68be@2x.png",
	"the-royal-file": "https://images.chesscomfiles.com/uploads/v1/group/917905.fa369df3.160x160o.6a907c240f09@2x.png",
	"hybrid-chess-federation": "https://images.chesscomfiles.com/uploads/v1/group/599005.5f0f639f.160x160o.58ef7f15a931@2x.png",
	"chess-universe": "https://images.chesscomfiles.com/uploads/v1/group/10249.266e0df6.160x160o.fa04d9151260@2x.png",
	"the-hindu": "https://images.chesscomfiles.com/uploads/v1/group/7289.0a9e40a7.160x160o.857c146cc699@2x.webp",
	"the-eternal": "https://images.chesscomfiles.com/uploads/v1/group/802974.6ec1c076.160x160o.316d25eb13a0@2x.png",
	"chess-on-earth-2": "https://images.chesscomfiles.com/uploads/v1/group/798446.cd88f307.160x160o.6e961f31cb24@2x.png",
	"eminence-in-shadow": "https://images.chesscomfiles.com/uploads/v1/group/869963.6f6b9f9f.160x160o.17f00fe1c011@2x.jpg",
	"the-club-of-195-countries": "https://images.chesscomfiles.com/uploads/v1/group/907907.2eef6a9e.160x160o.7e685e0bb3f2@2x.png",
	"chess-like-a-tiger": "https://images.chesscomfiles.com/uploads/v1/group/862719.52bd4e4e.160x160o.2e74f9c97832@2x.png"
};
function prettifySlug(slug) {
	return (slug || "").replace(/[-_]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()).trim();
}
function matchIdFromLink(link) {
	if (!link) return "";
	const parts = link.split("?")[0].split("#")[0].split("/").filter(Boolean);
	for (let i = parts.length - 1; i >= 0; i--) if (/^\d+$/.test(parts[i] ?? "")) return parts[i] ?? "";
	return "";
}
function slugFromClubApiId(idUrl) {
	if (!idUrl) return "";
	const parts = idUrl.split("/").filter(Boolean);
	return (parts[parts.length - 1] || "").toLowerCase();
}
function splitRow(line) {
	if (line.includes("	")) return line.split("	").map((c) => c.trim());
	const out = [];
	let cur = "";
	let inQuotes = false;
	for (let i = 0; i < line.length; i++) {
		const ch = line[i];
		if (ch === "\"") {
			if (inQuotes && line[i + 1] === "\"") {
				cur += "\"";
				i++;
			} else inQuotes = !inQuotes;
		} else if (ch === "," && !inQuotes) {
			out.push(cur.trim());
			cur = "";
		} else cur += ch;
	}
	out.push(cur.trim());
	return out;
}
function normalizeHeader(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}
var ROUND_HEADERS = /* @__PURE__ */ new Set([
	"round",
	"rnd",
	"r"
]);
var GROUP_HEADERS = /* @__PURE__ */ new Set([
	"group",
	"pool",
	"section"
]);
var HOME_HEADERS = new Set([
	"home",
	"cluba",
	"white",
	"team1",
	"teamA",
	"us",
	"club1",
	"a"
].map((s) => s.toLowerCase()));
var AWAY_HEADERS = new Set([
	"away",
	"clubb",
	"black",
	"team2",
	"teamB",
	"them",
	"club2",
	"opponent",
	"b"
].map((s) => s.toLowerCase()));
var LINK_HEADERS = /* @__PURE__ */ new Set([
	"match",
	"link",
	"url",
	"board",
	"matchurl",
	"matchlink"
]);
var SCORE_A_HEADERS = /* @__PURE__ */ new Set([
	"scorea",
	"homepts",
	"pointsa",
	"usscore",
	"score1"
]);
var SCORE_B_HEADERS = /* @__PURE__ */ new Set([
	"scoreb",
	"awaypts",
	"pointsb",
	"themscore",
	"score2"
]);
var RESULT_HEADERS = /* @__PURE__ */ new Set([
	"result",
	"score",
	"pts"
]);
function headerIndex(headers, names) {
	return headers.findIndex((h) => names.has(normalizeHeader(h)));
}
function parseScorePair(raw) {
	const m = raw.trim().match(/^(-?\d+(?:\.\d+)?)\s*[-:]\s*(-?\d+(?:\.\d+)?)$/);
	if (!m) return null;
	return {
		a: Number(m[1]),
		b: Number(m[2])
	};
}
function parseFlatTable(rows, title) {
	if (rows.length < 2) return null;
	const headers = rows[0] ?? [];
	const homeI = headerIndex(headers, HOME_HEADERS);
	const awayI = headerIndex(headers, AWAY_HEADERS);
	const linkI = headerIndex(headers, LINK_HEADERS);
	if (homeI < 0 || awayI < 0) return null;
	const roundI = headerIndex(headers, ROUND_HEADERS);
	const groupI = headerIndex(headers, GROUP_HEADERS);
	const scoreAI = headerIndex(headers, SCORE_A_HEADERS);
	const scoreBI = headerIndex(headers, SCORE_B_HEADERS);
	const resultI = headerIndex(headers, RESULT_HEADERS);
	const roundMap = /* @__PURE__ */ new Map();
	for (const row of rows.slice(1)) {
		const home = (row[homeI] || "").trim();
		const away = (row[awayI] || "").trim();
		if (!home || !away) continue;
		const clubA = home.toLowerCase().replace(/\s+/g, "-");
		const clubB = away.toLowerCase().replace(/\s+/g, "-");
		const roundName = roundI >= 0 ? row[roundI] || "Round 1" : "Round 1";
		const groupName = groupI >= 0 ? row[groupI] || "Open" : "Open";
		const link = linkI >= 0 ? row[linkI] || "" : "";
		let scoreA = null;
		let scoreB = null;
		if (scoreAI >= 0 && scoreBI >= 0) {
			const a = Number(row[scoreAI]);
			const b = Number(row[scoreBI]);
			if (!Number.isNaN(a) && !Number.isNaN(b)) {
				scoreA = a;
				scoreB = b;
			}
		} else if (resultI >= 0) {
			const pair = parseScorePair(row[resultI] || "");
			if (pair) {
				scoreA = pair.a;
				scoreB = pair.b;
			}
		}
		if (!roundMap.has(roundName)) roundMap.set(roundName, /* @__PURE__ */ new Map());
		const groups = roundMap.get(roundName);
		if (!groups.has(groupName)) groups.set(groupName, {
			clubs: /* @__PURE__ */ new Set(),
			matches: []
		});
		const g = groups.get(groupName);
		g.clubs.add(clubA);
		g.clubs.add(clubB);
		g.matches.push({
			clubA,
			clubB,
			link,
			scoreA,
			scoreB
		});
	}
	const rounds = [];
	for (const [name, groups] of roundMap) {
		const groupList = [];
		for (const [gName, g] of groups) groupList.push({
			name: gName,
			clubs: [...g.clubs],
			matches: g.matches
		});
		rounds.push({
			name,
			groups: groupList
		});
	}
	if (!rounds.length) return null;
	return {
		title,
		rounds
	};
}
function parseMatrix(text, title) {
	const rounds = [];
	let currentRound = null;
	let currentGroupName = null;
	let groupRows = [];
	function flushGroup() {
		if (!currentGroupName || !currentRound) {
			groupRows = [];
			currentGroupName = null;
			return;
		}
		const clubs = groupRows.map((r) => r.slug);
		const matches = [];
		for (let i = 0; i < clubs.length; i++) for (let j = i + 1; j < clubs.length; j++) {
			const cellIJ = (groupRows[i]?.cells[j] || "").trim();
			const cellJI = (groupRows[j]?.cells[i] || "").trim();
			let link = "";
			for (const c of [cellIJ, cellJI]) if (c && c.toLowerCase() !== "x") link = c;
			matches.push({
				clubA: clubs[i] ?? "",
				clubB: clubs[j] ?? "",
				link
			});
		}
		currentRound.groups.push({
			name: currentGroupName,
			clubs,
			matches
		});
		groupRows = [];
		currentGroupName = null;
	}
	for (const rawLine of text.split(/\r?\n/)) {
		const line = rawLine.trimEnd();
		if (!line.trim()) continue;
		const cells = splitRow(line);
		const first = (cells[0] || "").trim();
		if (!first) continue;
		if (/^round\b/i.test(first)) {
			flushGroup();
			if (currentRound) rounds.push(currentRound);
			currentRound = {
				name: first,
				groups: []
			};
			continue;
		}
		if (/^group\b/i.test(first)) {
			flushGroup();
			if (!currentRound) currentRound = {
				name: "Round 1",
				groups: []
			};
			currentGroupName = first;
			continue;
		}
		if (!currentGroupName) continue;
		const slug = first.toLowerCase().replace(/\s+/g, "-");
		groupRows.push({
			slug,
			cells: cells.slice(1)
		});
	}
	flushGroup();
	if (currentRound) rounds.push(currentRound);
	return {
		title,
		rounds
	};
}
function parseTournamentData(text, title = SAMPLE_TITLE) {
	const flat = parseFlatTable(text.split(/\r?\n/).map((l) => splitRow(l)).filter((r) => r.some((c) => c.trim())), title);
	if (flat && flat.rounds.some((r) => r.groups.some((g) => g.matches.length))) return flat;
	const matrix = parseMatrix(text, title);
	if (matrix.rounds.some((r) => r.groups.some((g) => g.clubs.length))) return matrix;
	throw new Error("Could not parse the sheet. Use a crosstable (Round / group / club slugs + match links) or a match list with Home, Away, and Match columns.");
}
function parseSample() {
	return parseTournamentData(SAMPLE_SHEET, SAMPLE_TITLE);
}
function extractSheetRef(url) {
	const trimmed = url.trim();
	const idMatch = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
	if (!idMatch?.[1]) return null;
	const gidMatch = trimmed.match(/[?&#]gid=([0-9]+)/) || trimmed.match(/gid%3D([0-9]+)/);
	return {
		id: idMatch[1],
		gid: gidMatch?.[1] ?? "0"
	};
}
function allMatchIds(tournament) {
	const ids = /* @__PURE__ */ new Set();
	for (const round of tournament.rounds) for (const group of round.groups) for (const match of group.matches) {
		const id = matchIdFromLink(match.link);
		if (id) ids.add(id);
	}
	return [...ids];
}
function allClubSlugs(tournament) {
	const slugs = /* @__PURE__ */ new Set();
	for (const round of tournament.rounds) for (const group of round.groups) for (const slug of group.clubs) slugs.add(slug);
	return [...slugs];
}
function matchViewFromPayload(payload, slugA, slugB) {
	if (!payload || payload.teams.length < 2) return null;
	const t1 = payload.teams[0];
	const t2 = payload.teams[1];
	let teamA = t1;
	let teamB = t2;
	const a = slugA.toLowerCase();
	const b = slugB.toLowerCase();
	if (t1.slug === a || t2.slug === b) {
		teamA = t1;
		teamB = t2;
	} else if (t2.slug === a || t1.slug === b) {
		teamA = t2;
		teamB = t1;
	}
	let scoreA = teamA.score;
	let scoreB = teamB.score;
	let forfeited = false;
	if (payload.status === "finished" && payload.minTeamPlayers != null) {
		const minReq = payload.minTeamPlayers;
		if (teamA.players !== teamB.players && (teamA.players < minReq || teamB.players < minReq)) {
			scoreA = teamA.players;
			scoreB = teamB.players;
			forfeited = true;
		}
	}
	return {
		status: payload.status || "registered",
		boards: payload.boards,
		timeClass: payload.timeClass || "daily",
		url: payload.url,
		scoreA,
		scoreB,
		forfeited
	};
}
function teamFromApi(team) {
	return {
		slug: slugFromClubApiId(team["@id"]),
		score: team.score == null ? null : Number(team.score),
		players: Array.isArray(team.players) ? team.players.length : 0
	};
}
//#endregion
export { matchIdFromLink as a, parseTournamentData as c, extractSheetRef as i, prettifySlug as l, allClubSlugs as n, matchViewFromPayload as o, allMatchIds as r, parseSample as s, CLUB_ICONS as t, teamFromApi as u };

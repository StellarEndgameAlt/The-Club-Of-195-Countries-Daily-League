import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const fetchMatchesFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      ids: z.array(z.string()).max(80),
    }),
  )
  .handler(async ({ data }) => {
    const { loadMatch } = await import("./chesscom.server");
    const unique = [...new Set(data.ids.map((id) => id.replace(/[^\d]/g, "")).filter(Boolean))];
    const results = await Promise.all(unique.map((id) => loadMatch(id)));
    return results.filter((m) => m != null);
  });

export const fetchClubsFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      slugs: z.array(z.string()).max(40),
    }),
  )
  .handler(async ({ data }) => {
    const { loadClub } = await import("./chesscom.server");
    const unique = [...new Set(data.slugs.map((s) => s.trim().toLowerCase()).filter(Boolean))];
    return Promise.all(unique.map((slug) => loadClub(slug)));
  });

export const fetchSheetFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      url: z.string().min(8).max(500),
    }),
  )
  .handler(async ({ data }) => {
    const { loadSheetText } = await import("./chesscom.server");
    const text = await loadSheetText(data.url);
    return { text };
  });

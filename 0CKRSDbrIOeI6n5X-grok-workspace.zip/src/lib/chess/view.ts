import { slugFromClubApiId } from "./parse";
import type { MatchView } from "./types";

export type MatchPayload = {
  id: string;
  url: string;
  status: string;
  boards: number | null;
  timeClass: string;
  minTeamPlayers: number | null;
  teams: Array<{
    slug: string;
    score: number | null;
    players: number;
  }>;
};

export function matchViewFromPayload(
  payload: MatchPayload | null | undefined,
  slugA: string,
  slugB: string,
): MatchView | null {
  if (!payload || payload.teams.length < 2) return null;
  const t1 = payload.teams[0]!;
  const t2 = payload.teams[1]!;
  let teamA = t1;
  let teamB = t2;
  const a = slugA.toLowerCase();
  const b = slugB.toLowerCase();
  if (t1.slug === a || t2.slug === b) {
    teamA = t1;
    teamB = t2;
  } else if (t2.slug === a || t1.slug === b) {
    teamA = t2;
    teamB = t1;
  }

  let scoreA = teamA.score;
  let scoreB = teamB.score;
  let forfeited = false;
  if (payload.status === "finished" && payload.minTeamPlayers != null) {
    const minReq = payload.minTeamPlayers;
    if (
      teamA.players !== teamB.players &&
      (teamA.players < minReq || teamB.players < minReq)
    ) {
      scoreA = teamA.players;
      scoreB = teamB.players;
      forfeited = true;
    }
  }

  return {
    status: payload.status || "registered",
    boards: payload.boards,
    timeClass: payload.timeClass || "daily",
    url: payload.url,
    scoreA,
    scoreB,
    forfeited,
  };
}

export function teamFromApi(team: {
  "@id"?: string;
  score?: number | string;
  players?: unknown[];
}): MatchPayload["teams"][number] {
  return {
    slug: slugFromClubApiId(team["@id"]),
    score: team.score == null ? null : Number(team.score),
    players: Array.isArray(team.players) ? team.players.length : 0,
  };
}

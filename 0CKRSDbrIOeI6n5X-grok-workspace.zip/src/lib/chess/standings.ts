import type { ClubStanding, GroupData, MatchView } from "./types";

export function pointsFromScores(
  scoreA: number | null | undefined,
  scoreB: number | null | undefined,
): number | null {
  if (scoreA == null || scoreB == null || Number.isNaN(scoreA) || Number.isNaN(scoreB)) {
    return null;
  }
  if (scoreA > scoreB) return 1;
  if (scoreA < scoreB) return 0;
  return 0.5;
}

export function pointsLabel(p: number | null): string {
  if (p === 1) return "1";
  if (p === 0) return "0";
  if (p === 0.5) return "½";
  return "·";
}

export function matchKey(a: string, b: string): string {
  return `${a}|${b}`;
}

export function resolveView(
  views: Record<string, MatchView | null>,
  a: string,
  b: string,
): { view: MatchView; flipped: boolean } | null {
  const direct = views[matchKey(a, b)];
  if (direct) return { view: direct, flipped: false };
  const flipped = views[matchKey(b, a)];
  if (flipped) return { view: flipped, flipped: true };
  return null;
}

export function scoresFor(
  rec: { view: MatchView; flipped: boolean } | null,
  fallback?: { scoreA?: number | null; scoreB?: number | null },
): { a: number | null; b: number | null; forfeited: boolean } {
  if (rec) {
    return rec.flipped
      ? {
          a: rec.view.scoreB,
          b: rec.view.scoreA,
          forfeited: rec.view.forfeited,
        }
      : {
          a: rec.view.scoreA,
          b: rec.view.scoreB,
          forfeited: rec.view.forfeited,
        };
  }
  return {
    a: fallback?.scoreA ?? null,
    b: fallback?.scoreB ?? null,
    forfeited: false,
  };
}

export function computeStandings(
  group: GroupData,
  views: Record<string, MatchView | null>,
): ClubStanding[] {
  const table = new Map<string, ClubStanding>();
  for (const slug of group.clubs) {
    table.set(slug, {
      slug,
      played: 0,
      wins: 0,
      draws: 0,
      losses: 0,
      points: 0,
      boardPoints: 0,
      tiebreak: 0,
    });
  }

  const pairwise = new Map<string, number>();

  for (const match of group.matches) {
    const rec = resolveView(views, match.clubA, match.clubB);
    const { a, b } = scoresFor(rec, match);
    const pts = pointsFromScores(a, b);
    if (pts == null || a == null || b == null) continue;
    const home = table.get(match.clubA);
    const away = table.get(match.clubB);
    if (!home || !away) continue;
    home.played += 1;
    away.played += 1;
    home.points += pts;
    away.points += 1 - pts;
    home.boardPoints += a;
    away.boardPoints += b;
    if (pts === 1) {
      home.wins += 1;
      away.losses += 1;
    } else if (pts === 0) {
      away.wins += 1;
      home.losses += 1;
    } else {
      home.draws += 1;
      away.draws += 1;
    }
    pairwise.set(matchKey(match.clubA, match.clubB), pts);
    pairwise.set(matchKey(match.clubB, match.clubA), 1 - pts);
  }

  for (const club of table.values()) {
    let tb = 0;
    for (const other of table.values()) {
      if (other.slug === club.slug) continue;
      const pts = pairwise.get(matchKey(club.slug, other.slug));
      if (pts == null) continue;
      tb += pts * other.points;
    }
    club.tiebreak = tb;
  }

  return [...table.values()].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.tiebreak !== a.tiebreak) return b.tiebreak - a.tiebreak;
    if (b.boardPoints !== a.boardPoints) return b.boardPoints - a.boardPoints;
    return a.slug.localeCompare(b.slug);
  });
}

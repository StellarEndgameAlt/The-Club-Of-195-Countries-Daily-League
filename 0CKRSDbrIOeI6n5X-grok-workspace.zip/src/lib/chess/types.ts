export const HOST_CLUB_SLUG = "the-club-of-195-countries";
export const HOST_CLUB_NAME = "The Club of 195 Countries";
export const HOST_CLUB_URL =
  "https://www.chess.com/club/the-club-of-195-countries";

export type ClubProfile = {
  slug: string;
  name: string;
  icon: string;
  url?: string;
  members?: number;
};

export type MatchLink = {
  clubA: string;
  clubB: string;
  link: string;
  scoreA?: number | null;
  scoreB?: number | null;
};

export type GroupData = {
  name: string;
  clubs: string[];
  matches: MatchLink[];
};

export type RoundData = {
  name: string;
  groups: GroupData[];
};

export type Tournament = {
  title: string;
  rounds: RoundData[];
};

export type MatchView = {
  status: string;
  boards: number | null;
  timeClass: string;
  url: string;
  scoreA: number | null;
  scoreB: number | null;
  forfeited: boolean;
};

export type ClubStanding = {
  slug: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  points: number;
  boardPoints: number;
  tiebreak: number;
};

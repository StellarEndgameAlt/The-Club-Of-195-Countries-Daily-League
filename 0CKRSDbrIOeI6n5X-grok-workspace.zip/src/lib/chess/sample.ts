export const SAMPLE_SHEET = `Round 1
group 1
hot-chilli-checkmate	x	https://www.chess.com/club/matches/1983144	https://www.chess.com/club/matches/1983618	https://www.chess.com/club/matches/1983156	https://www.chess.com/club/matches/1983186
the-royal-file	https://www.chess.com/club/matches/1983144	x	https://www.chess.com/club/matches/1983620	https://www.chess.com/club/matches/1983556	https://www.chess.com/club/matches/1983646
hybrid-chess-federation	https://www.chess.com/club/matches/1983618	https://www.chess.com/club/matches/1983620	x	https://www.chess.com/club/matches/1983698	https://www.chess.com/club/matches/1983700
chess-universe	https://www.chess.com/club/matches/1983156	https://www.chess.com/club/matches/1983556	https://www.chess.com/club/matches/1983698	x	https://www.chess.com/club/matches/chess-universe/1983712
the-hindu	https://www.chess.com/club/matches/1983186	https://www.chess.com/club/matches/1983646	https://www.chess.com/club/matches/1983700	https://www.chess.com/club/matches/chess-universe/1983712	x

group 2
the-eternal	x	https://www.chess.com/club/matches/chess-on-earth-2/1983388	https://www.chess.com/club/matches/the-eternal/1983390	https://www.chess.com/club/matches/the-club-of-195-countries/1983394	https://www.chess.com/club/matches/chess-like-a-tiger/1983396
chess-on-earth-2	https://www.chess.com/club/matches/chess-on-earth-2/1983388	x	https://www.chess.com/club/matches/chess-on-earth-2/1983716	https://www.chess.com/club/matches/chess-on-earth-2/1983544	https://www.chess.com/club/matches/chess-on-earth-2/1983688
eminence-in-shadow	https://www.chess.com/club/matches/the-eternal/1983390	https://www.chess.com/club/matches/chess-on-earth-2/1983716	x	https://www.chess.com/club/matches/the-club-of-195-countries/1983634	https://www.chess.com/club/matches/chess-like-a-tiger/1983686
the-club-of-195-countries	https://www.chess.com/club/matches/the-club-of-195-countries/1983394	https://www.chess.com/club/matches/chess-on-earth-2/1983544	https://www.chess.com/club/matches/the-club-of-195-countries/1983634	x	https://www.chess.com/club/matches/chess-like-a-tiger/1983526
chess-like-a-tiger	https://www.chess.com/club/matches/chess-like-a-tiger/1983396	https://www.chess.com/club/matches/chess-on-earth-2/1983688	https://www.chess.com/club/matches/chess-like-a-tiger/1983686	https://www.chess.com/club/matches/chess-like-a-tiger/1983526	x
`;

export const SAMPLE_TITLE = "Daily Club Tournament";

export const CLUB_ICONS: Record<string, string> = {
  "hot-chilli-checkmate":
    "https://images.chesscomfiles.com/uploads/v1/group/856887.ca0c5404.160x160o.1b7d241b68be@2x.png",
  "the-royal-file":
    "https://images.chesscomfiles.com/uploads/v1/group/917905.fa369df3.160x160o.6a907c240f09@2x.png",
  "hybrid-chess-federation":
    "https://images.chesscomfiles.com/uploads/v1/group/599005.5f0f639f.160x160o.58ef7f15a931@2x.png",
  "chess-universe":
    "https://images.chesscomfiles.com/uploads/v1/group/10249.266e0df6.160x160o.fa04d9151260@2x.png",
  "the-hindu":
    "https://images.chesscomfiles.com/uploads/v1/group/7289.0a9e40a7.160x160o.857c146cc699@2x.webp",
  "the-eternal":
    "https://images.chesscomfiles.com/uploads/v1/group/802974.6ec1c076.160x160o.316d25eb13a0@2x.png",
  "chess-on-earth-2":
    "https://images.chesscomfiles.com/uploads/v1/group/798446.cd88f307.160x160o.6e961f31cb24@2x.png",
  "eminence-in-shadow":
    "https://images.chesscomfiles.com/uploads/v1/group/869963.6f6b9f9f.160x160o.17f00fe1c011@2x.jpg",
  "the-club-of-195-countries":
    "https://images.chesscomfiles.com/uploads/v1/group/907907.2eef6a9e.160x160o.7e685e0bb3f2@2x.png",
  "chess-like-a-tiger":
    "https://images.chesscomfiles.com/uploads/v1/group/862719.52bd4e4e.160x160o.2e74f9c97832@2x.png",
};

export const DEFAULT_CLUB_ICON =
  "https://www.chess.com/bundles/web/images/user-image.007dad08.svg";

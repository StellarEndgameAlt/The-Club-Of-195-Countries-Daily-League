import type { GroupData, MatchLink, RoundData, Tournament } from "./types";
import { SAMPLE_SHEET, SAMPLE_TITLE } from "./sample";

export function prettifySlug(slug: string): string {
  return (slug || "")
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

export function matchIdFromLink(link: string): string {
  if (!link) return "";
  const clean = link.split("?")[0].split("#")[0];
  const parts = clean.split("/").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^\d+$/.test(parts[i] ?? "")) return parts[i] ?? "";
  }
  return "";
}

export function slugFromClubApiId(idUrl: string | undefined): string {
  if (!idUrl) return "";
  const parts = idUrl.split("/").filter(Boolean);
  return (parts[parts.length - 1] || "").toLowerCase();
}

function splitRow(line: string): string[] {
  if (line.includes("\t")) return line.split("\t").map((c) => c.trim());
  // CSV with quoted fields
  const out: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === "," && !inQuotes) {
      out.push(cur.trim());
      cur = "";
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}

function looksLikeUrl(value: string): boolean {
  return /^https?:\/\//i.test(value) || /chess\.com\/club\/matches/i.test(value);
}

function normalizeHeader(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

const ROUND_HEADERS = new Set(["round", "rnd", "r"]);
const GROUP_HEADERS = new Set(["group", "pool", "section"]);
const HOME_HEADERS = new Set([
  "home",
  "cluba",
  "white",
  "team1",
  "teamA",
  "us",
  "club1",
  "a",
].map((s) => s.toLowerCase()));
const AWAY_HEADERS = new Set([
  "away",
  "clubb",
  "black",
  "team2",
  "teamB",
  "them",
  "club2",
  "opponent",
  "b",
].map((s) => s.toLowerCase()));
const LINK_HEADERS = new Set([
  "match",
  "link",
  "url",
  "board",
  "matchurl",
  "matchlink",
]);
const SCORE_A_HEADERS = new Set([
  "scorea",
  "homepts",
  "pointsa",
  "usscore",
  "score1",
]);
const SCORE_B_HEADERS = new Set([
  "scoreb",
  "awaypts",
  "pointsb",
  "themscore",
  "score2",
]);
const RESULT_HEADERS = new Set(["result", "score", "pts"]);

function headerIndex(headers: string[], names: Set<string>): number {
  return headers.findIndex((h) => names.has(normalizeHeader(h)));
}

function parseScorePair(raw: string): { a: number; b: number } | null {
  const m = raw.trim().match(/^(-?\d+(?:\.\d+)?)\s*[-:]\s*(-?\d+(?:\.\d+)?)$/);
  if (!m) return null;
  return { a: Number(m[1]), b: Number(m[2]) };
}

function parseFlatTable(rows: string[][], title: string): Tournament | null {
  if (rows.length < 2) return null;
  const headers = rows[0] ?? [];
  const homeI = headerIndex(headers, HOME_HEADERS);
  const awayI = headerIndex(headers, AWAY_HEADERS);
  const linkI = headerIndex(headers, LINK_HEADERS);
  if (homeI < 0 || awayI < 0) return null;

  const roundI = headerIndex(headers, ROUND_HEADERS);
  const groupI = headerIndex(headers, GROUP_HEADERS);
  const scoreAI = headerIndex(headers, SCORE_A_HEADERS);
  const scoreBI = headerIndex(headers, SCORE_B_HEADERS);
  const resultI = headerIndex(headers, RESULT_HEADERS);

  const roundMap = new Map<string, Map<string, { clubs: Set<string>; matches: MatchLink[] }>>();

  for (const row of rows.slice(1)) {
    const home = (row[homeI] || "").trim();
    const away = (row[awayI] || "").trim();
    if (!home || !away) continue;
    const clubA = home.toLowerCase().replace(/\s+/g, "-");
    const clubB = away.toLowerCase().replace(/\s+/g, "-");
    const roundName = roundI >= 0 ? row[roundI] || "Round 1" : "Round 1";
    const groupName = groupI >= 0 ? row[groupI] || "Open" : "Open";
    const link = linkI >= 0 ? row[linkI] || "" : "";
    let scoreA: number | null = null;
    let scoreB: number | null = null;
    if (scoreAI >= 0 && scoreBI >= 0) {
      const a = Number(row[scoreAI]);
      const b = Number(row[scoreBI]);
      if (!Number.isNaN(a) && !Number.isNaN(b)) {
        scoreA = a;
        scoreB = b;
      }
    } else if (resultI >= 0) {
      const pair = parseScorePair(row[resultI] || "");
      if (pair) {
        scoreA = pair.a;
        scoreB = pair.b;
      }
    }

    if (!roundMap.has(roundName)) roundMap.set(roundName, new Map());
    const groups = roundMap.get(roundName)!;
    if (!groups.has(groupName)) {
      groups.set(groupName, { clubs: new Set(), matches: [] });
    }
    const g = groups.get(groupName)!;
    g.clubs.add(clubA);
    g.clubs.add(clubB);
    g.matches.push({ clubA, clubB, link, scoreA, scoreB });
  }

  const rounds: RoundData[] = [];
  for (const [name, groups] of roundMap) {
    const groupList: GroupData[] = [];
    for (const [gName, g] of groups) {
      groupList.push({
        name: gName,
        clubs: [...g.clubs],
        matches: g.matches,
      });
    }
    rounds.push({ name, groups: groupList });
  }
  if (!rounds.length) return null;
  return { title, rounds };
}

function parseMatrix(text: string, title: string): Tournament {
  const rounds: RoundData[] = [];
  let currentRound: RoundData | null = null;
  let currentGroupName: string | null = null;
  let groupRows: { slug: string; cells: string[] }[] = [];

  function flushGroup() {
    if (!currentGroupName || !currentRound) {
      groupRows = [];
      currentGroupName = null;
      return;
    }
    const clubs = groupRows.map((r) => r.slug);
    const matches: MatchLink[] = [];
    for (let i = 0; i < clubs.length; i++) {
      for (let j = i + 1; j < clubs.length; j++) {
        const cellIJ = (groupRows[i]?.cells[j] || "").trim();
        const cellJI = (groupRows[j]?.cells[i] || "").trim();
        let link = "";
        for (const c of [cellIJ, cellJI]) {
          if (c && c.toLowerCase() !== "x") link = c;
        }
        matches.push({
          clubA: clubs[i] ?? "",
          clubB: clubs[j] ?? "",
          link,
        });
      }
    }
    currentRound.groups.push({
      name: currentGroupName,
      clubs,
      matches,
    });
    groupRows = [];
    currentGroupName = null;
  }

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trimEnd();
    if (!line.trim()) continue;
    const cells = splitRow(line);
    const first = (cells[0] || "").trim();
    if (!first) continue;

    if (/^round\b/i.test(first)) {
      flushGroup();
      if (currentRound) rounds.push(currentRound);
      currentRound = { name: first, groups: [] };
      continue;
    }
    if (/^group\b/i.test(first)) {
      flushGroup();
      if (!currentRound) {
        currentRound = { name: "Round 1", groups: [] };
      }
      currentGroupName = first;
      continue;
    }
    if (!currentGroupName) {
      // Treat a header-like first row as a new implicit group if we already have a round
      continue;
    }
    const slug = first.toLowerCase().replace(/\s+/g, "-");
    groupRows.push({ slug, cells: cells.slice(1) });
  }
  flushGroup();
  if (currentRound) rounds.push(currentRound);
  return { title, rounds };
}

export function parseTournamentData(
  text: string,
  title = SAMPLE_TITLE,
): Tournament {
  const rows = text
    .split(/\r?\n/)
    .map((l) => splitRow(l))
    .filter((r) => r.some((c) => c.trim()));

  const flat = parseFlatTable(rows, title);
  if (flat && flat.rounds.some((r) => r.groups.some((g) => g.matches.length))) {
    return flat;
  }

  const matrix = parseMatrix(text, title);
  if (matrix.rounds.some((r) => r.groups.some((g) => g.clubs.length))) {
    return matrix;
  }

  throw new Error(
    "Could not parse the sheet. Use a crosstable (Round / group / club slugs + match links) or a match list with Home, Away, and Match columns.",
  );
}

export function parseSample(): Tournament {
  return parseTournamentData(SAMPLE_SHEET, SAMPLE_TITLE);
}

export function extractSheetRef(url: string): { id: string; gid: string } | null {
  const trimmed = url.trim();
  const idMatch = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (!idMatch?.[1]) return null;
  const gidMatch =
    trimmed.match(/[?&#]gid=([0-9]+)/) || trimmed.match(/gid%3D([0-9]+)/);
  return { id: idMatch[1], gid: gidMatch?.[1] ?? "0" };
}

export function allMatchIds(tournament: Tournament): string[] {
  const ids = new Set<string>();
  for (const round of tournament.rounds) {
    for (const group of round.groups) {
      for (const match of group.matches) {
        const id = matchIdFromLink(match.link);
        if (id) ids.add(id);
      }
    }
  }
  return [...ids];
}

export function allClubSlugs(tournament: Tournament): string[] {
  const slugs = new Set<string>();
  for (const round of tournament.rounds) {
    for (const group of round.groups) {
      for (const slug of group.clubs) slugs.add(slug);
    }
  }
  return [...slugs];
}

export function looksLikeUrlCell(value: string): boolean {
  return looksLikeUrl(value);
}

import { useMutation, useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Globe, Trophy } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { GroupTable } from "@/components/group-table";
import { SourcePanel } from "@/components/source-panel";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  fetchClubsFn,
  fetchMatchesFn,
  fetchSheetFn,
} from "@/lib/chess/functions";
import {
  allClubSlugs,
  allMatchIds,
  parseSample,
  parseTournamentData,
} from "@/lib/chess/parse";
import {
  HOST_CLUB_NAME,
  HOST_CLUB_SLUG,
  HOST_CLUB_URL,
  type ClubProfile,
  type Tournament,
} from "@/lib/chess/types";
import type { MatchPayload } from "@/lib/chess/view";
import { cn } from "@/lib/utils";

const SHEET_KEY = "club195-sheet-url";

export const Route = createFileRoute("/")({ component: Home });

function readStoredUrl() {
  if (typeof window === "undefined") return "";
  try {
    return localStorage.getItem(SHEET_KEY) ?? "";
  } catch {
    return "";
  }
}

function Home() {
  const sample = useMemo(() => parseSample(), []);
  const [url, setUrl] = useState("");
  const [tournament, setTournament] = useState<Tournament>(sample);
  const [sourceLabel, setSourceLabel] = useState("bundled sample");
  const [roundIndex, setRoundIndex] = useState(0);
  const [parseError, setParseError] = useState<string | null>(null);

  useEffect(() => {
    const stored = readStoredUrl();
    if (stored) setUrl(stored);
  }, []);

  const applyText = (text: string, label: string) => {
    const parsed = parseTournamentData(text, tournament.title);
    setTournament(parsed);
    setRoundIndex(0);
    setParseError(null);
    setSourceLabel(label);
  };

  const sheetMut = useMutation({
    mutationFn: (sheetUrl: string) => fetchSheetFn({ data: { url: sheetUrl } }),
    onSuccess: (res, sheetUrl) => {
      applyText(res.text, "Google Sheet");
      try {
        localStorage.setItem(SHEET_KEY, sheetUrl);
      } catch {
        /* ignore */
      }
    },
    onError: (err) => {
      setParseError(err instanceof Error ? err.message : "Could not load sheet.");
    },
  });

  const round = tournament.rounds[roundIndex] ?? tournament.rounds[0];
  const slugs = useMemo(
    () => (round ? allClubSlugs({ title: tournament.title, rounds: [round] }) : []),
    [round, tournament.title],
  );
  const matchIds = useMemo(
    () => (round ? allMatchIds({ title: tournament.title, rounds: [round] }) : []),
    [round, tournament.title],
  );

  const clubsQuery = useQuery({
    queryKey: ["clubs", slugs.join(",")],
    queryFn: () => fetchClubsFn({ data: { slugs } }),
    enabled: slugs.length > 0,
  });

  const matchesQuery = useQuery({
    queryKey: ["matches", matchIds.join(",")],
    queryFn: () => fetchMatchesFn({ data: { ids: matchIds } }),
    enabled: matchIds.length > 0,
  });

  const clubs: Record<string, ClubProfile> = {};
  for (const slug of slugs) {
    clubs[slug] = {
      slug,
      name: slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      icon: "",
      url: `https://www.chess.com/club/${slug}`,
    };
  }
  for (const club of clubsQuery.data ?? []) {
    clubs[club.slug] = club;
  }

  const payloads: Record<string, MatchPayload | null> = {};
  for (const match of matchesQuery.data ?? []) {
    payloads[match.id] = match;
  }

  const host = clubs[HOST_CLUB_SLUG];

  return (
    <div className="min-h-dvh">
      <header className="bg-ink text-accent-foreground">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6 sm:py-10 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-xl">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-accent-foreground/70">
              Chess.com club
            </p>
            <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              {HOST_CLUB_NAME}
            </h1>
            <p className="mt-3 max-w-prose text-sm leading-relaxed text-accent-foreground/75">
              Pairings, points, and board links from the club sheet. Live scores
              pull from Chess.com when a match URL is present.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-3 rounded-lg border border-accent-foreground/15 bg-accent-foreground/10 px-3 py-2">
              {host?.icon ? (
                <img
                  src={host.icon}
                  alt=""
                  className="size-10 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="flex size-10 items-center justify-center rounded-full bg-accent">
                  <Globe className="size-5" />
                </span>
              )}
              <div>
                <p className="text-sm font-medium">Host club</p>
                <p className="text-xs text-accent-foreground/70">
                  {host?.members ? `${host.members.toLocaleString()} members` : "Join on Chess.com"}
                </p>
              </div>
            </div>
            <Button asChild variant="secondary">
              <a href={HOST_CLUB_URL} target="_blank" rel="noreferrer">
                Join the club
              </a>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-6 px-4 py-8 sm:px-6">
        <SourcePanel
          url={url}
          onUrlChange={setUrl}
          onLoadUrl={() => {
            if (!url.trim()) return;
            sheetMut.mutate(url.trim());
          }}
          onLoadSample={() => {
            setTournament(sample);
            setRoundIndex(0);
            setParseError(null);
            setSourceLabel("bundled sample");
          }}
          onLoadText={(text) => {
            try {
              applyText(text, "pasted table");
            } catch (err) {
              setParseError(err instanceof Error ? err.message : "Could not parse table.");
            }
          }}
          loading={sheetMut.isPending}
          error={parseError}
          sourceLabel={sourceLabel}
        />

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              {tournament.title}
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Win 1 · Draw ½ · Loss 0. Tiebreak is Sonneborn–Berger from match points.
            </p>
          </div>
          {tournament.rounds.length > 1 ? (
            <div className="flex flex-wrap gap-2">
              {tournament.rounds.map((r, i) => (
                <Button
                  key={r.name + i}
                  size="sm"
                  variant={i === roundIndex ? "default" : "secondary"}
                  onClick={() => setRoundIndex(i)}
                >
                  {r.name}
                </Button>
              ))}
            </div>
          ) : (
            <p className="inline-flex items-center gap-2 text-sm text-muted-foreground">
              <Trophy className="size-4 text-accent" />
              {round?.name ?? "Standings"}
            </p>
          )}
        </div>

        {!round ? (
          <p className="rounded-xl border border-border bg-card px-4 py-10 text-center text-sm text-muted-foreground">
            No rounds in this sheet yet.
          </p>
        ) : (
          <div className="space-y-6">
            {round.groups.map((group) => (
              <GroupTable
                key={group.name}
                group={group}
                clubs={clubs}
                payloads={payloads}
                loading={matchesQuery.isLoading}
              />
            ))}
          </div>
        )}

        {clubsQuery.isLoading ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        ) : null}

        <section className="rounded-xl border border-border bg-card px-5 py-4">
          <h3 className="font-display text-base font-semibold">How points work</h3>
          <ul className="mt-2 grid gap-1 text-sm text-muted-foreground sm:grid-cols-3">
            <li>
              <span className={cn("font-medium text-win")}>Win</span> — 1 match point
            </li>
            <li>
              <span className="font-medium text-draw">Draw</span> — ½ match point
            </li>
            <li>
              <span className="font-medium text-loss">Loss</span> — 0 match points
            </li>
          </ul>
          <p className="mt-2 text-xs text-muted-foreground">
            Each score cell is a live Chess.com match. Board points (e.g. 3–1½) come from
            the match; the Pts column is match points. An asterisk is a forfeit on player count.
          </p>
        </section>
      </main>
    </div>
  );
}

import { useState } from "react";
import { ChevronDown, LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function SourcePanel({
  url,
  onUrlChange,
  onLoadUrl,
  onLoadSample,
  onLoadText,
  loading,
  error,
  sourceLabel,
}: {
  url: string;
  onUrlChange: (value: string) => void;
  onLoadUrl: () => void;
  onLoadSample: () => void;
  onLoadText: (text: string) => void;
  loading: boolean;
  error: string | null;
  sourceLabel: string;
}) {
  const [open, setOpen] = useState(false);
  const [paste, setPaste] = useState("");

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
        <label className="min-w-0 flex-1">
          <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Google Sheet
          </span>
          <Input
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            placeholder="Paste a published Google Sheets URL"
            inputMode="url"
            autoComplete="off"
            onKeyDown={(e) => {
              if (e.key === "Enter") onLoadUrl();
            }}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <Button onClick={onLoadUrl} disabled={loading || !url.trim()}>
            {loading ? <LoaderCircle className="animate-spin" /> : null}
            Load sheet
          </Button>
          <Button variant="secondary" onClick={onLoadSample} disabled={loading}>
            Sample tournament
          </Button>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Source: {sourceLabel}. Share the sheet with “Anyone with the link”.
      </p>
      {error ? (
        <p className="mt-2 text-sm text-loss" role="alert">
          {error}
        </p>
      ) : null}

      <button
        type="button"
        className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-accent"
        onClick={() => setOpen((v) => !v)}
      >
        Sheet format
        <ChevronDown
          className={cn(
            "size-3.5 transition-transform duration-[var(--motion-quick)]",
            open && "rotate-180",
          )}
        />
      </button>
      {open ? (
        <div className="mt-3 space-y-3 text-sm text-muted-foreground">
          <p>
            Crosstable: a <code className="text-foreground">Round</code> row, a{" "}
            <code className="text-foreground">group</code> row, then one row per
            club slug with Chess.com match URLs and <code className="text-foreground">x</code> on
            the diagonal.
          </p>
          <p>
            Or a match list with columns{" "}
            <code className="text-foreground">Home</code>,{" "}
            <code className="text-foreground">Away</code>,{" "}
            <code className="text-foreground">Match</code>, optional{" "}
            <code className="text-foreground">Round</code> /{" "}
            <code className="text-foreground">Group</code> /{" "}
            <code className="text-foreground">Result</code>.
          </p>
          <textarea
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
            rows={6}
            placeholder="Or paste TSV / CSV here"
            className="w-full rounded-md border border-border bg-bg px-3 py-2 font-mono text-xs text-foreground"
          />
          <Button
            variant="outline"
            size="sm"
            disabled={!paste.trim()}
            onClick={() => onLoadText(paste)}
          >
            Parse pasted table
          </Button>
        </div>
      ) : null}
    </div>
  );
}

import { ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { matchIdFromLink, prettifySlug } from "@/lib/chess/parse";
import {
  computeStandings,
  matchKey,
  pointsFromScores,
  pointsLabel,
  resolveView,
  scoresFor,
} from "@/lib/chess/standings";
import { HOST_CLUB_SLUG, type ClubProfile, type GroupData } from "@/lib/chess/types";
import { matchViewFromPayload, type MatchPayload } from "@/lib/chess/view";
import { cn } from "@/lib/utils";

function findMatch(group: GroupData, a: string, b: string) {
  return group.matches.find(
    (m) =>
      (m.clubA === a && m.clubB === b) || (m.clubA === b && m.clubB === a),
  );
}

function viewsFromPayloads(
  group: GroupData,
  payloads: Record<string, MatchPayload | null>,
) {
  const views: Record<string, ReturnType<typeof matchViewFromPayload>> = {};
  for (const match of group.matches) {
    const id = matchIdFromLink(match.link);
    const payload = id ? payloads[id] : null;
    const view = matchViewFromPayload(payload, match.clubA, match.clubB);
    views[matchKey(match.clubA, match.clubB)] = view;
  }
  return views;
}

export function GroupTable({
  group,
  clubs,
  payloads,
  loading,
}: {
  group: GroupData;
  clubs: Record<string, ClubProfile>;
  payloads: Record<string, MatchPayload | null>;
  loading: boolean;
}) {
  const views = viewsFromPayloads(group, payloads);
  const standings = computeStandings(group, views);
  const order = standings.map((s) => s.slug);

  return (
    <section className="overflow-hidden rounded-xl border border-border bg-card shadow-[0_12px_32px_-24px_rgba(18,22,15,0.45)]">
      <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 sm:px-5">
        <h2 className="font-display text-lg font-semibold tracking-tight text-foreground">
          {prettifySlug(group.name)}
        </h2>
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {group.clubs.length} clubs
        </p>
      </header>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse text-sm">
          <thead>
            <tr className="bg-ink text-accent-foreground">
              <th className="sticky left-0 z-10 bg-ink px-4 py-3 text-left font-display text-xs font-medium tracking-wide">
                Club
              </th>
              {order.map((slug) => {
                const club = clubs[slug];
                return (
                  <th
                    key={slug}
                    className="px-2 py-3 text-center font-medium"
                    title={club?.name ?? prettifySlug(slug)}
                  >
                    <span className="mx-auto flex size-8 items-center justify-center overflow-hidden rounded-full bg-secondary">
                      {club?.icon ? (
                        <img
                          src={club.icon}
                          alt=""
                          className="size-8 object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <span className="text-[10px] text-muted-foreground">
                          {(club?.name ?? slug).slice(0, 1).toUpperCase()}
                        </span>
                      )}
                    </span>
                  </th>
                );
              })}
              <th className="px-3 py-3 text-center font-display text-xs font-medium tracking-wide">
                Pts
              </th>
              <th className="px-3 py-3 text-center font-display text-xs font-medium tracking-wide">
                TB
              </th>
            </tr>
          </thead>
          <tbody>
            {order.map((rowSlug, rank) => {
              const club = clubs[rowSlug];
              const standing = standings[rank];
              const isHost = rowSlug === HOST_CLUB_SLUG;
              return (
                <tr
                  key={rowSlug}
                  className={cn(
                    "border-t border-border",
                    isHost ? "bg-accent/10" : rank % 2 === 1 ? "bg-secondary/40" : "bg-card",
                  )}
                >
                  <th
                    className={cn(
                      "sticky left-0 z-10 min-w-[196px] px-4 py-2.5 text-left font-medium",
                      isHost ? "bg-card" : rank % 2 === 1 ? "bg-secondary/40" : "bg-card",
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-5 text-right font-sans text-xs tabular-nums text-muted-foreground">
                        {rank + 1}
                      </span>
                      <span className="size-8 overflow-hidden rounded-full bg-secondary">
                        {club?.icon ? (
                          <img
                            src={club.icon}
                            alt=""
                            className="size-8 object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : null}
                      </span>
                      <span className="min-w-0">
                        <span className="block truncate font-medium leading-tight">
                          {club?.name ?? prettifySlug(rowSlug)}
                        </span>
                        {isHost ? (
                          <Badge variant="default" className="mt-1 text-[10px]">
                            Host
                          </Badge>
                        ) : null}
                      </span>
                    </div>
                  </th>
                  {order.map((colSlug) => {
                    if (rowSlug === colSlug) {
                      return (
                        <td
                          key={colSlug}
                          className="px-2 py-2 text-center text-muted-foreground"
                        >
                          —
                        </td>
                      );
                    }
                    const match = findMatch(group, rowSlug, colSlug);
                    if (!match) {
                      return (
                        <td key={colSlug} className="px-2 py-2 text-center text-muted-foreground">
                          ·
                        </td>
                      );
                    }
                    const rec = resolveView(views, rowSlug, colSlug);
                    const fallback =
                      rowSlug === match.clubA
                        ? match
                        : { scoreA: match.scoreB, scoreB: match.scoreA };
                    const { a, b, forfeited } = scoresFor(rec, fallback);
                    const pts = pointsFromScores(a, b);
                    const href = match.link || rec?.view.url;
                    return (
                      <td key={colSlug} className="px-1.5 py-2 text-center">
                        {loading && pts == null && href ? (
                          <Skeleton className="mx-auto h-8 w-12" />
                        ) : href ? (
                          <a
                            href={href}
                            target="_blank"
                            rel="noreferrer"
                            className={cn(
                              "inline-flex min-h-11 min-w-11 flex-col items-center justify-center rounded-md px-2 py-1 text-xs font-semibold tabular-nums transition-colors duration-[var(--motion-quick)] hover:bg-secondary",
                              pts === 1 && "text-win",
                              pts === 0 && "text-loss",
                              pts === 0.5 && "text-draw",
                              pts == null && "text-muted-foreground",
                            )}
                            title="Open Chess.com match"
                          >
                            <span>
                              {pts == null
                                ? "Board"
                                : `${a}\u2013${b}${forfeited ? "*" : ""}`}
                            </span>
                            {pts != null ? (
                              <span className="text-[10px] font-medium uppercase tracking-wide">
                                {pointsLabel(pts)}
                              </span>
                            ) : (
                              <ExternalLink className="mt-0.5 size-3" />
                            )}
                          </a>
                        ) : (
                          <span className="text-muted-foreground">·</span>
                        )}
                      </td>
                    );
                  })}
                  <td className="px-3 py-2 text-center font-semibold tabular-nums">
                    {standing?.points ?? 0}
                  </td>
                  <td className="px-3 py-2 text-center text-muted-foreground tabular-nums">
                    {(standing?.tiebreak ?? 0).toFixed(1)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
